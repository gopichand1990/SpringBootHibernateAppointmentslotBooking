package com.hospital;

import org.springframework.boot.SpringApplication;


//working code for insertion into hibernate database
public class Main {
    public static void main(String[] args) {
        SpringApplication.run(Controller.class, args);
    }
}
