package com.hospital;

import org.hibernate.Query;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.List;

public class DBUtil {
    /*private static void updateBankById(Session session) {
        Bank bank = session.get(Bank.class, 2);
        if(bank != null){
            //changing name from ICICI to HDFC
            bank.setName("KOTAK");
            session.beginTransaction();
            session.update(bank);
            session.getTransaction().commit();
        }else {
            System.out.println("Bank doesn't exist with provideded Id..");
        }
    }
    private static void getBankbyId(Session session) {
        Bank bank = session.get(Bank.class, 2);
        if(bank != null){
            System.out.println(bank);
        }else{
            System.out.println("Bank doesn't exist with provideded Id..");
        }

    }*/


    //get doctor based on id
    public List<Doctor> getDoctorbasedonId(Session session, int doctorId) {
        List<Doctor> l = new ArrayList<Doctor>();
        try {
            String HQL = "FROM Doctor where doctorId=:doctorId ";
            Query<Doctor> query = session.createQuery(HQL, Doctor.class);
            query.setParameter("doctorId", doctorId);
            List<Doctor> list = ((org.hibernate.query.Query) query).list();
            System.out.println("size of list is" + list.size());
            System.out.println("based i=on doctor_id " + list.get(0).getWorkingHrs());
            list.forEach(System.out::println);
            l = list;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return l;
    }

    //get booking based on doctor_id and date
    public List<Booking> getBookingbasedondoctorIdanddate(Session session, int doctorId, String date) {
        List<Booking> l1 = new ArrayList<Booking>();
        try {
            // This is where Tinku fixed, the right hand side of equals should contain the name sent to setParamter emthod.
            String HQL = "FROM Booking where doctorId=:doctorId and BookingDate=:date ";
            Query<Booking> query = session.createQuery(HQL, Booking.class);
            query.setParameter("doctorId", doctorId);
            query.setParameter("BookingDate", date);
            List<Booking> list = ((org.hibernate.query.Query) query).list();
            System.out.println("size of list is" + list.size());
            list.forEach(System.out::println);
            l1 = list;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return l1;
    }


    //com.hospital.Doctor creation
    static void createDoctor(Session session) {
        session.beginTransaction();
        Integer id =(Integer)session.save(getDoctor());
        System.out.println("doctor is created  with Id::"+id);
        session.getTransaction().commit();
    }
     static com.hospital.Doctor getDoctor(){
        com.hospital.Doctor doctor=new com.hospital.Doctor();
        doctor.setDoctorId(3);
        doctor.setName("Bob");
        doctor.setDepartment("Dentist");
        doctor.setWorkingHrs("10:00-12:00");
        return doctor;
    }

    //com.hospital.Booking creation


    public static  Booking getBooking(String time, int patient_id, int doctor_id, String booking_date) {
        Booking booking = new Booking();
        booking.setBookingTime(time);
        booking.setPatientId(patient_id);
        booking.setDoctorId(doctor_id);
        booking.setBookingDate(booking_date);
        return booking;
    }


    public static Integer createBooking(Session session, Booking booking) {
        session.beginTransaction();
        Integer id = (Integer) session.save(booking);
        System.out.println("Booking is created  with Id::" + id);
        session.getTransaction().commit();
        return id;
    }
}
