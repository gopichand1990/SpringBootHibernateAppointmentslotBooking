package com.hospital;

import org.hibernate.Session;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
@RestController
public class Controller {
    private DBUtil dBUtil;
    private HibernateUtil hibernateUtil;

    /*
     * Constructor
     */
    public Controller() {
        this.dBUtil = new DBUtil();
        this.hibernateUtil = new HibernateUtil();
    }

    @RequestMapping(value = "/Booking", produces = {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE})
    @GetMapping
    public Response book_Slot(@RequestParam("department") String department, @RequestParam("doctorId") int doctorId, @RequestParam("date") String date, @RequestParam("patientPreferedTime") String patientPreferedTime, @RequestParam("patientId") int patientId) {
        //JSONObject json = new JSONObject();
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            List<Booking> l1 = new ArrayList<Booking>();
            l1 = dBUtil.getBookingbasedondoctorIdanddate(session, doctorId, date);
            String t = "";
            if (l1.size() == 0) {
                //System.out.println("no bookings for particular date can proceed for booking");
            }
            //single booking available for particular  date
            if (l1.size() == 1) {
                t = l1.get(0).getBookingTime();
            }
            ArrayList<String> b = new ArrayList<String>();
            //multiple bookings available to doctor on same day
            if (l1.size() > 1) {
                for (int i = 0; i < l1.size(); i++) {
                    b.add(l1.get(i).getBookingTime());
                }
            }

            List<Doctor> l2 = new ArrayList<Doctor>();
            l2 = dBUtil.getDoctorbasedonId(session, doctorId);
            String w = "";
            if (l2.size() == 0) {
                return Response.ok().build();
            } else {
                w = l2.get(0).getWorkingHrs();
            }

            List<String> al = new ArrayList<String>();
            System.out.println("working hrs are " + w);
            String[] hrs = w.split("-");
            String startTime = "";
            String endTime = "";
            if (hrs.length > 1) {
                startTime = hrs[0];
                endTime = hrs[1];
            }

            //add time slots to arraylist
            String temp = hrs[0]; // 10-12
            //int count = 10;
            while (!endTime.equals(temp)) {
                System.out.println("temp is " + temp + " " + endTime);
                if (temp.contains(":30")) {
                    String[] a = temp.split(":");
                    temp = Integer.parseInt(a[0]) + 1 + ":00";
                    al.add(temp);
                    System.out.println("If " + temp);
                } else {
                    String[] d = temp.split(":");
                    temp = d[0] + ":30";
                    al.add(temp);
                    System.out.println("Else " + temp);
                }
                //count--;
            }

            //booking for preffered time already exist
            if (t.contains(patientPreferedTime)) {
                System.out.println("corresponding time is already booked");

                 return Response.status(Response.Status.METHOD_NOT_ALLOWED).build();

                //throw new RuntimeException("com.hospital.Booking slot at the time mentioned is  is not allowed please select different time");

            }

            if (al.contains(patientPreferedTime)) {
                Booking booking = dBUtil.getBooking(patientPreferedTime, patientId, doctorId, date);
                System.out.println("booking is " + booking);
                Integer i1 = dBUtil.createBooking(session, booking);
                return Response.ok("Booking succeeded").build();
            } else {
                return Response.ok("slot already booked ").build();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return Response.ok().build();
    }
}
