package com.hospital;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Table(name = "Doctor")
class Doctor {
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "incrementor")
    @GenericGenerator(name = "incrementer", strategy = "increment")
    private int id;


    @Column(name = "doctorId")
    private int doctorId;

    @Column(name = "doctorName")
    private String name;

    @Column(name = "department")
    private String department;

    @Column(name = "workingHrs")
    private String workingHrs;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getWorkingHrs() {
        return workingHrs;
    }

    public void setWorkingHrs(String workingHrs) {
        this.workingHrs = workingHrs;
    }

    @Override
    public String toString() {
        return "Doctor{" +
                "id=" + id +
                ", doctorId=" + doctorId +
                ", name='" + name + '\'' +
                ", department='" + department + '\'' +
                ", workingHrs='" + workingHrs + '\'' +
                '}';
    }
}