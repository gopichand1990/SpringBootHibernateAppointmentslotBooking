package com.hospital;/*perfectly working code for insertion into database
import org.hibernate.HibernateException;
import org.hibernate.Session;


import javax.persistence.ManyToOne;

import static javafx.scene.input.KeyCode.H;

public class com.hospital.ClientTest {

    public static void main(String[] args) {
        com.hospital.HibernateUtil hibernateUtil=new com.hospital.HibernateUtil();
        Bank bank=new Bank();
        try {

            Session session = hibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            bank.setId(1);
            bank.setName("ICICI");
            session.save(bank);
            session.getTransaction().commit();

        } catch (HibernateException e) {
            e.printStackTrace();
        }



    }
}*/
//working for all cases of CRUD operation

import org.hibernate.HibernateException;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.List;

public class ClientTest {
    public static void main(String[] args) {
        HibernateUtil hibernateUtil = new HibernateUtil();
        DBUtil dbUtil = new DBUtil();
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            DBUtil DBUtil = new DBUtil();
            List<Doctor> ll = new ArrayList<Doctor>();
            List<Booking> ll2 = new ArrayList<Booking>();

            DBUtil.createDoctor(session);
            ll = dbUtil.getDoctorbasedonId(session, 2);
            System.out.println("com.hospital.Doctor arraylist is " + ll);
            //ll2 = dbUtil.getBookingbasedondoctorIdanddate(session, 2, "2020/10/10");
            //System.out.println("com.hospital.Booking arraylist is " + ll2);
        } catch (HibernateException e) {
            e.printStackTrace();
        }

        //SpringApplication.run(EmailPollingServiceApplication.class, args);

    }

}
